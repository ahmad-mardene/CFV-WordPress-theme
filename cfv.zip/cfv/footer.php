<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package CFV
 */

?>

<footer class= container>
        <h1>Contact us & Leave a comment</h1>
        <form class="needs-validation" novalidate>
            <div class="form-row">
                <div class="col-md-6 mb-3">
                    <label for="validationTooltip01">Name</label>
                    <input type="text" class="form-control" id="validationTooltip01" placeholder="Name (Optional)" required>
                    <div class="valid-tooltip">
                        Looks good!
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <label for="validationTooltip03">City</label>
                    <input type="text" class="form-control" id="validationTooltip03" placeholder="City" required>
                    <div class="invalid-tooltip">
                        Please provide a valid city.
                    </div>
                </div>
            </div>
            <div class="form-row">
                <div class="col-md-12 mb-3">
                    <textarea rows="4" cols="150" name="comment" form="usrform">
                        Enter text here...</textarea>
                </div>
            </div>
            <button class="btn btn-primary" type="submit">Submit form</button>
        </form>
        &copy; CFV 2018
    </footer>

<?php wp_footer(); ?>

</body>
</html>
