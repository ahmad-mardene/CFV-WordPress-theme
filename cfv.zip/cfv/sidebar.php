<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package CFV
 */

if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}
?>
<?php wp_sidebar(); ?>

 <div class=" container col-lg-4">
            <aside>
                <div class="media">
                    <img class="mr-3" src=".../64x64" alt="Generic placeholder image">
                    <div class="media-body">
                        <h5 class="mt-0">Media heading</h5> Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudi
                    </div>
                </div>
                <hr>
                <div class="media">
                    <img class="mr-3" src=".../64x64" alt="Generic placeholder image">
                    <div class="media-body">
                        <h5 class="mt-0">Media heading</h5> Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitud
                    </div>
                </div>
                <hr>
                <div class="media">
                    <img class="mr-3" src=".../64x64" alt="Generic placeholder image">
                    <div class="media-body">
                        <h5 class="mt-0">Media heading</h5> Cras nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate
                    </div>
                </div>
            </aside>
        </div>
    </div>
  </div>
